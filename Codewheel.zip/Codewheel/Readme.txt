

Codewheel Generator, V1.0.0

May, 2008

Tom Lackamp http://www.mindspring.com/~tom2000


Installation:

Download Codewheel.msi.

Install the program by double-clicking the .msi file.

Tte program will be automatically installed in C:\Program Files\Codewheel,
and the installer will create a desktop icon.

Select the desktop icon, then press F2.  Rename the icon to something
meaningful, such as "Codewheel."

Double-click the desktop icon to launch the program. 
