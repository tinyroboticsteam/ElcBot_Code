#ifndef FORMSCHEDULE_H
#define FORMSCHEDULE_H

#include <QDialog>
#include <QDebug>
#include <QVector>
#include <fstream>
#include <QMessageBox>
using std::ofstream;
namespace Ui {
class FormSchedule;
}

class FormSchedule : public QDialog
{
    Q_OBJECT

public:
    explicit FormSchedule(QWidget *parent = 0);
    ~FormSchedule();

private:
    QMessageBox msgBox;
    bool isOpenFile;
    bool isUpdateGraph;
    QVector<double> time,data;
    ofstream fout;
    bool ok;
    bool isSaveData;
    int count;
    int timeOld;
    char file[16];
    char nameFile[16];

    Ui::FormSchedule *ui;
private slots:
    void SetData(QString,QString,QString);
    void CloseForm();
    void StopSetData();
    void ClearGraph();
    void SetHV(bool);
signals:
    void EnabledButtonSchedule();

    // QWidget interface
protected:
    void closeEvent(QCloseEvent *event);
};

#endif // FORMSCHEDULE_H

/*  Автор: Georgy_Smith  */
/*  Изменен:   18.10.18  */
