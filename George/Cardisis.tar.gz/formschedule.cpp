#include "formschedule.h"
#include "ui_formschedule.h"

FormSchedule::FormSchedule(QWidget *parent) : QDialog(parent), ui(new Ui::FormSchedule){
    isUpdateGraph = false;

    ui->setupUi(this);
    ui->checkBoxVH->setChecked(true);
    ui->isSave->setEnabled(false);
    connect(ui->buttonClose,SIGNAL(clicked(bool)),this,SLOT(CloseForm()));
    connect(ui->stopButton,SIGNAL(clicked(bool)),this,SLOT(StopSetData()));
    ui->widget->addGraph();
    ui->widget->setInteraction(QCP::iRangeZoom,true);   // Включаем взаимодействие удаления/приближения
    ui->widget->setInteraction(QCP::iRangeDrag, true);  // Включаем взаимодействие перетаскивания графика
    //ui->widget->axisRect()->setRangeDrag(Qt::Vertical);   // Включаем перетаскивание только по горизонтальной оси
    ui->widget->axisRect()->setRangeDrag(Qt::Horizontal);

    ui->widget->axisRect()->setRangeZoom(Qt::Horizontal);   // Включаем удаление/приближение только по горизонтальной оси
    ui->widget->yAxis->setRange(400, 900);//Для оси Oy
    ui->widget->xAxis->setLabel("time");
    ui->widget->yAxis->setLabel("data");
    // ui->widget->axisRect()->setRangeDragAxes(0,0);
    connect(ui->checkBoxVH,SIGNAL(clicked(bool)),this,SLOT(SetHV(bool)));
    timeOld = 0;
    isOpenFile = true;

    //ui->widget->axisRect()->setRangeDrag(Qt::Horizontal | Qt::Vertical);
}

void FormSchedule::CloseForm(){
    emit EnabledButtonSchedule();
    this->close();
}

void FormSchedule::StopSetData(){
    //Обработка кнопки остановки графика
    if(isUpdateGraph){
        ui->stopButton->setText("Новый график");
        isUpdateGraph = false;
        // Включаем перетаскивание только по горизонтальной оси
        ui->widget->axisRect()->setRangeDrag(Qt::Horizontal);
        ui->widget->axisRect()->setRangeZoom(Qt::Horizontal);

        ui->checkBoxVH->setEnabled(true);
        ui->isSave->setEnabled(false);
        ui->isSave->setChecked(false);
        ui->checkBoxVH->setChecked(true);
         //ui->widget->replot();
        //qDebug() << "set horizontal";
    }
    else{
        ClearGraph();
        ui->checkBoxVH->setEnabled(false);
        ui->isSave->setEnabled(true);
        ui->checkBoxVH->setChecked(false);
        ui->stopButton->setText("Остановить");
        isUpdateGraph = true;
        ui->widget->axisRect()->setRangeDrag(Qt::Vertical);   // Включаем перетаскивание только по горизонтальной оси
        ui->widget->axisRect()->setRangeZoom(Qt::Vertical);
        // qDebug() << "setVertical";
    }
}

void FormSchedule::SetData(QString time, QString data, QString file){
    //Выполняется когла есть соединение с платой
    if(ui->isSave->isChecked()){
        if(isOpenFile){
            char c[16];
            //for(int i = 0;i <16;i++){
            //    this->nameFile[i] = file.at(i).toUtf8();
            //}

            strncpy(c,qPrintable(file),16);

            qDebug()<< this->file;//qDebug()<< this->file;qDebug()<< this->file;
            fout.open(c, std::ios_base::out | std::ios_base::trunc);
            isOpenFile = false;
        }
        if(!fout.is_open()){
            msgBox.setText("Файл не может быть открыт, установите новое соединение!");
            msgBox.setIcon(QMessageBox::Warning);
            msgBox.exec();
            ui->isSave->setChecked(false);
            qDebug() << "Error! Файл не может быть открыт, установите новое соединение!";
        }
        else{
            fout << '[' << time.toInt(&ok,10) << '#' << data.toInt(&ok,10) << ']';
        }
    }
    else{
        fout.close();
        isOpenFile = true;
    }

    if(isUpdateGraph){

    //Массивы координат точек
    //ui->widget->xAxis->setRange(0, 5000);
        this->time.push_back(time.toInt(&ok,10));
        this->data.push_back(data.toInt(&ok,10));
    //ui->widget->clearGraphs();//Если нужно, то очищаем все графики
    //Добавляем один график в widget
    //delete(ui->widget->graph());
    //ui->widget->addGraph();
    //Говорим, что отрисовать нужно график по нашим двум массивам x и y
        ui->widget->graph()->setData(this->time, this->data);

    //ui->widget->graph(0)->addData(5,10);
    //Подписываем оси Ox и Oy
    //Установим область, которая будет показываться на графике
    /* if(time.toInt(&ok,10) >timeOld){
        ui->widget->xAxis->setRange(time.toInt(&ok,10),time.toInt(&ok,10)+5000);//Для оси Ox
        timeOld = time.toInt(&ok,10)+5000;
        qDebug()<<timeOld;
    }*/
        ui->widget->xAxis->setRange(time.toInt(&ok,10)-20000,time.toInt(&ok,10));//Для оси Ox
    //Для показа границ по оси Oy сложнее, так как надо по правильному
    //вычислить минимальное и максимальное значение в векторах
    //ui->widget->graph(0)->rescaleAxes();
    //И перерисуем график на нашем widget
        ui->widget->replot();
    }
}
void FormSchedule::ClearGraph(){
    time.clear();
    data.clear();
}
void FormSchedule::SetHV(bool is){
    if(is){
        ui->widget->axisRect()->setRangeDrag(Qt::Horizontal);
        ui->widget->axisRect()->setRangeZoom(Qt::Horizontal);
    }
    else {
        ui->widget->axisRect()->setRangeDrag(Qt::Vertical);
        ui->widget->axisRect()->setRangeZoom(Qt::Vertical);
    }
}

void FormSchedule::closeEvent(QCloseEvent *event)
{
    CloseForm();
}
FormSchedule::~FormSchedule()
{
    delete ui;
}

/*  Автор: Georgy_Smith  */
/*  Изменен:   18.10.17  */
