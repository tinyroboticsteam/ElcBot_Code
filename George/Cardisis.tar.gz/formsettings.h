#ifndef FORMSETTINGS_H
#define FORMSETTINGS_H

#include <QWidget>
#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>
#include <QLabel>
#include <QDialog>

namespace Ui {
class FormSettings;
}

class FormSettings : public QDialog
{
    Q_OBJECT

public:
    explicit FormSettings(QWidget *parent = 0);
    ~FormSettings();

private:
    Ui::FormSettings *ui;
    QSerialPort *newPort;
    QLabel *label;
    bool isActivPort = false;
private slots:
    void GetPort();
    void SetCOM();
    void CloseForm();
signals:
    void AcceptSettings(QSerialPort *, QString);
    void GetIsPort(bool);
    void EnabledButtonSettings();
    void ClearGraph();

    // QWidget interface
protected:
    void closeEvent(QCloseEvent *event);
};

#endif // FORMSETTINGS_H

/*  Автор: Georgy_Smith  */
/*  Изменен:   18.10.18  */
