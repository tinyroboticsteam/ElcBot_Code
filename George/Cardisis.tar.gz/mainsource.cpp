#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent):QWidget(parent){
    schedule = new FormSchedule(this); //Формы
    settings = new FormSettings(this);
    isGetDataTime = false;
    isGetDataSignal = false;
    list = new QListWidget();
    line = new QLineEdit();

//    settings->setWindowFlag(Qt::WindowTitleHint);

    isGetDataSignal = false;
    list = new QListWidget();
    line = new QLineEdit();

    settings->setWindowFlag(Qt::WindowTitleHint);

    scrollCb = new QCheckBox("Автоскролл");
    scrollCb->setChecked(true); //Автоскролл установлен по умолчанию
    write = new QCheckBox("Запись");
    write->setEnabled(false);

    buttonAccept = new QPushButton("Принять");
    buttonShow = new QPushButton("График");
    buttonSettings = new QPushButton("Настройки COM");
    buttonClose = new QPushButton("Выход");
    buttonAccept->setSizePolicy(QSizePolicy::Preferred,QSizePolicy::Expanding);
    buttonSettings->setDefault(true);
    buttonShow->setSizePolicy(QSizePolicy::Preferred,QSizePolicy::Expanding);
    port = new QSerialPort();
    isActivePort = false;

    QVBoxLayout *layoutButt = new QVBoxLayout();
    layoutButt->addWidget(buttonAccept);
    layoutButt->addWidget(buttonShow);
    layoutButt->addWidget(buttonSettings);
    layoutButt->addWidget(buttonClose);

    QHBoxLayout *layoutItemAndButt = new QHBoxLayout();
    layoutItemAndButt->addWidget(list);
    layoutItemAndButt->addLayout(layoutButt);

    QHBoxLayout *layoutLineAndCbox = new QHBoxLayout();
    layoutLineAndCbox->addWidget(line);
    layoutLineAndCbox->addWidget(scrollCb);
    layoutLineAndCbox->addWidget(write);

    QVBoxLayout *layoutMain = new QVBoxLayout();
    layoutMain->addLayout(layoutItemAndButt);
    layoutMain->addLayout(layoutLineAndCbox);

    connect(buttonAccept,SIGNAL(clicked(bool)),this,SLOT(AcceptClickd())); //Ждем события для отправки сообщения
    connect(buttonShow,SIGNAL(clicked(bool)),this,SLOT(ShowSchedule()));
    connect(buttonSettings,SIGNAL(clicked(bool)),this,SLOT(ShowSettings())); //Ждем события для открытия окна
    connect(buttonClose,SIGNAL(clicked(bool)),this,SLOT(close())); //Закрыть ПО
    connect(settings,SIGNAL(AcceptSettings(QSerialPort*,QString)),this,SLOT(SetPort(QSerialPort*,QString)));
    connect(settings,SIGNAL(GetIsPort(bool)),this,SLOT(SetActivePort(bool)));
    connect(schedule,SIGNAL(EnabledButtonSchedule()),this,SLOT(EnabledButtonSchedule())); //Нужно для отображения кнопок после закрытия
    connect(settings,SIGNAL(EnabledButtonSettings()),this,SLOT(EnabledButtonSettings())); //---||----
    connect(line,SIGNAL(returnPressed()),SLOT(AcceptClickd())); //Ожидания ENTER для строки
    connect(this,SIGNAL(SetData(QString,QString,QString)),schedule,SLOT(SetData(QString,QString,QString)));
    //Очистка графика из настроек
    connect(settings,SIGNAL(ClearGraph()),schedule,SLOT(ClearGraph()));


    setLayout(layoutMain);
    setMinimumSize(550,250); //Фиксация окна
    setMaximumSize(550,250); //----||----
    setWindowTitle("Cardisis");

    list->addItem("Выберите устройство");
    buttonAccept->setEnabled(false);
}

void MainWindow::AcceptClickd(){
    //qDebug() << "OK";
    //Отправить на COM порт
    if(isActivePort){
        QString str = line->text();
        if(str == "clear"){
            list->clear(); //Чистим экран с командами
        }
        else{
            QByteArray byte;
            byte += str + '/'; //Символ '/' означает завершение приема строки, как на отправку так и на прием
            port->write(byte);
        }
        line->setText("");
        //qDebug() << isActivePort;
    }
}
QString saveDataInform;
void MainWindow::Read(){
    serialData = port->readAll();
    if(serialData !="/"){
        if(serialData == "["){
            //говорим о готовности принемать данные time
            isGetDataTime = true;
        }
        if(isGetDataTime){
            if(serialData != "[" && serialData != "(")
            time += QString::fromStdString(serialData.toStdString());
        }
        if(serialData == "("){
            isGetDataTime = false;
            isGetDataSignal = true;
        }
        if(isGetDataSignal){
            if(serialData!="(" && serialData!="#"){
                signal += QString::fromStdString(serialData.toStdString());
            }
        }
        if(serialData == "#"){
            isGetDataSignal = false;
            isGetDataTime = false;
        }
        saveDataInform += QString::fromStdString(serialData.toStdString());
    }
    else{
        saveDataInform += QString::fromStdString(serialData.toStdString());
        //list->addItem(saveDataInform);
        //qDebug() <<saveDataInform; //Собраная строка
        saveDataInform = "";
        //fSerialData результат принятый c COM порта
        if( list->count()>10000){ //Автоматическое освобождение памяти, очистка списка по достижению 10000 строк
            list->clear(); //добавить диструктор
            list->addItem("Список очищен");
        }
        //list->addItem("time ");
        //list->addItem(time); //Добавляем результат в список
        //list->addItem("signal ");
        //list->addItem(signal);

        emit SetData(time,signal,file);
        if(scrollCb->isChecked()){
            list->scrollToBottom(); //Автоскролл
        }
        //qDebug() <<"time";
        //qDebug() <<time;
        //qDebug() <<"signal";
        //qDebug() <<signal;
        //записывает пустые строки в переменные
        time = "";
        signal = "";
    }
}

void MainWindow::ShowSchedule(){
    schedule->show();
    buttonShow->setEnabled(false);
    schedule->exec();
}

void MainWindow::ShowSettings(){
    //this->setEnabled(false); //Заблокировать главное меню
    settings->show();
    buttonSettings->setEnabled(false);
    //settings->exec();

}

void MainWindow::SetPort(QSerialPort *newPort, QString file){
    port = newPort;
    connect(port,SIGNAL(readyRead()),this,SLOT(Read())); //если есть сигнал выводим его
    //qDebug() << file;
    this->file = file;
}

void MainWindow::SetActivePort(bool isActivePort){
    this->isActivePort = isActivePort; //Запретить управление!!!
    if(isActivePort){
        buttonAccept->setEnabled(true);
        list->clear();
    }
    else{
        list->clear();
        buttonAccept->setEnabled(false);
        list->addItem("Выберите устройство");
    }
}

void MainWindow::EnabledButtonSettings(){
    //this->setEnabled(true); //Разблокировать
    buttonSettings->setEnabled(true);
}
void MainWindow::EnabledButtonSchedule(){
    //this->setEnabled(true); //Разблокировать
    buttonShow->setEnabled(true);
}

/*  Автор: Georgy_Smith  */
/*  Изменен:   18.10.17  */
