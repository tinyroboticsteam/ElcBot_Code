#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "formsettings.h"
#include "formschedule.h"

#include <QDebug>
#include <QDialog>
#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QPushButton>
#include <QCheckBox>
#include <QListWidget>
#include <QLabel>
#include <QLineEdit>
#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>

#include <QStringListModel>

class MainWindow: public QWidget{
    Q_OBJECT
public:
    MainWindow(QWidget *parent =0);
    //~MainWindow();
private:
    QWidget *widget;
    QLabel *label;
    QLineEdit *line; //Строка для отправки события
    QListWidget *list; //Список с сообщениями
    QCheckBox *scrollCb; //Автопрокрутка
    QCheckBox *write; //Нахуй не надо
    QPushButton *buttonAccept; //Кнопка для отправки команды в COM порт
    QPushButton *buttonShow; //Показать ебалу
    QPushButton *buttonSettings; //Настройки, для COM порта
    QPushButton *buttonClose; //Закрыть ебалу
    QSerialPort *port; //Serial port
    QString file;
    QByteArray serialData; //Массив из байт
    //int time;
    //int signal;
    bool isGetDataTime;
    bool isGetDataSignal;
    FormSchedule *schedule;
    FormSettings *settings;
    QString fSerialData; //Результат приема сообщения
    QString time;
    QString signal;
    bool isActivePort;
private slots:
    void AcceptClickd(); //Слот для совершения события, в моем случае это отправка сообщения =)
    void ShowSchedule(); //Показать ебалу
    void ShowSettings();
    void SetPort(QSerialPort *, QString);
    void SetActivePort(bool);
    void Read();
    void EnabledButtonSettings();
    void EnabledButtonSchedule();
signals:
    void SetData(QString,QString,QString);
};

#endif // MAINWINDOW_H

/*  Автор: Georgy_Smith  */
/*  Изменен:   17.10.17  */
