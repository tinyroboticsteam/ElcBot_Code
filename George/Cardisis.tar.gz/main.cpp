#include <QApplication>
#include "mainwindow.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow *mainWindow = new MainWindow();
    mainWindow->show();
    return a.exec();
}

/*  Автор: Georgy_Smith  */
/*  Изменен:   15.10.17  */

//Написать диструктор для QWigetList в mainsource и заново создать таблицу
