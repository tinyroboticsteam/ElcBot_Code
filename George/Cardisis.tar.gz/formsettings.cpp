#include "formsettings.h"
#include "ui_formsettings.h"
#include <QDebug>

FormSettings::FormSettings(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::FormSettings)
{
    ui->setupUi(this);
    connect(ui->buttonAccept,SIGNAL(clicked(bool)),this,SLOT(CloseForm()));
    connect(ui->buttonRefresh,SIGNAL(clicked(bool)),this,SLOT(GetPort()));
    connect(ui->buttonSet,SIGNAL(clicked(bool)),this,SLOT(SetCOM()));
    newPort = new QSerialPort();
}
void FormSettings::GetPort(){

    newPort->setPortName(ui->urlCOM->text()); //Устройство
    newPort->open(QIODevice::ReadWrite); //Открыть на чтение и запись ttyACM0
    //qDebug() << newPort->error();
    if(!isActivPort){
        switch (newPort->error()){
        case QSerialPort::NoError:
            ui->portState->setText("Соединение установлено");
            isActivPort = true;
            ui->buttonRefresh->setText("Отключить");
            ui->saveFile->setEnabled(false);
            //очишаем масив графика
            //qDebug() << "connect";
            emit ClearGraph();

            newPort->setBaudRate(QSerialPort::Baud9600);
            newPort->setDataBits(QSerialPort::Data8);
            newPort->setFlowControl(QSerialPort::NoFlowControl);
            newPort->setParity(QSerialPort::NoParity);
            newPort->setStopBits(QSerialPort::OneStop);
            newPort->setReadBufferSize(1); //Читать по 1 байту

            emit AcceptSettings(newPort, ui->saveFile->text());
            emit GetIsPort(isActivPort);
            break;
        case QSerialPort::PermissionError:
            ui->portState->setText("Устройство занято");
            break;
        case QSerialPort::DeviceNotFoundError:
            ui->portState->setText("Устройство не найдено");
            break;
        case QSerialPort::OpenError:
            newPort->close();
            ui->portState->setText("Устройство уже подключено, отключение");
            ui->buttonRefresh->setText("Подключить");
            ui->saveFile->setEnabled(true);
            isActivPort = false;
            emit GetIsPort(isActivPort);
            break;
        default:
            ui->portState->setText("Неизвестная ошибка");
        }
    }
    else{
        newPort->close();
        ui->buttonRefresh->setText("Подключить");
        isActivPort = false;
        emit GetIsPort(isActivPort);
        ui->saveFile->setEnabled(true);
        ui->portState->setText("Устройство отключено");
    }
}

void FormSettings::SetCOM(){
    ui->urlCOM->setText(ui->lineCOM->text());
    ui->lineCOM->setText("");
}

void FormSettings::CloseForm(){
    emit EnabledButtonSettings();
    this->close();
}

void FormSettings::closeEvent(QCloseEvent *event)
{
    CloseForm();
}

FormSettings::~FormSettings()
{
    //qDebug() << "";
    delete ui;
}

/*  Автор: Georgy_Smith  */
/*  Изменен:   17.10.17  */
